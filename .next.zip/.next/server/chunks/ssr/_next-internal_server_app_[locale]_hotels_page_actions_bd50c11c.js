module.exports=[17796,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_hotels_page_actions_bd50c11c.js.map