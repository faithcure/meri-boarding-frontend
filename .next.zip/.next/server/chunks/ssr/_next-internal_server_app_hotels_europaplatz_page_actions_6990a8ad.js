module.exports=[55795,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hotels_europaplatz_page_actions_6990a8ad.js.map