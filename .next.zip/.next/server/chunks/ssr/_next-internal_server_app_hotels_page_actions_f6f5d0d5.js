module.exports=[20061,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hotels_page_actions_f6f5d0d5.js.map