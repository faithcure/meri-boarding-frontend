module.exports=[94466,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reservation_page_actions_af81dd7e.js.map