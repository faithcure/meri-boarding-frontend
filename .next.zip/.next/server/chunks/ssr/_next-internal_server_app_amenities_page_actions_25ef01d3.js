module.exports=[28760,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_amenities_page_actions_25ef01d3.js.map