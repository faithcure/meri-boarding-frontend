module.exports=[91965,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_privacy_page_actions_2c4fa42a.js.map