module.exports=[32096,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_services_page_actions_ccd3946b.js.map