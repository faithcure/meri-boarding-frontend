module.exports=[68060,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_hotels_europaplatz_page_actions_aee5b5aa.js.map