module.exports=[46777,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hotels_flamingo_page_actions_d82689cd.js.map