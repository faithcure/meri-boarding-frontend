module.exports=[77752,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_hotels_hildesheim_page_actions_0abf9d99.js.map