module.exports=[32377,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_hotels_flamingo_page_actions_4203d006.js.map