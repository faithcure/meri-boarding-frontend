module.exports=[31184,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_amenities_page_actions_c1b5d3c7.js.map