module.exports=[27539,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_impressum_page_actions_6a61f142.js.map