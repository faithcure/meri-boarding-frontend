module.exports=[53967,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_reservation_page_actions_a5d8c37a.js.map