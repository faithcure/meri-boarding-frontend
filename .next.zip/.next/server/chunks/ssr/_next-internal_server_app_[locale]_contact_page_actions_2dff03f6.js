module.exports=[83582,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_contact_page_actions_2dff03f6.js.map