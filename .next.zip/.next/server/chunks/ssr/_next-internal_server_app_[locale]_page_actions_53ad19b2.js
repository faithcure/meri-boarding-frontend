module.exports=[54710,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_page_actions_53ad19b2.js.map