module.exports=[48164,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_agb_page_actions_fc17de7a.js.map